<?php namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
    protected $table = 'mahasiswa';

    public function getData()
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);
        return $builder->get()->getResult();
    }
   
    public function insertData($data)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);
        return $builder->insert($data);
    }

    public function updateData($data, $id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);
        $builder->where('id_mahasiswa', $id);
        return $builder->update($data);
    }

    public function deleteData($id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);
        $builder->where('id_mahasiswa', $id);
        return $builder->delete();
    }
}