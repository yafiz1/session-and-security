<section class="resume-section">
    <div class="resume-section-content">
       
        <h3 class="mb-5"><?php echo $title ?></h3>
            
        <?php echo form_open_multipart('mahasiswa/submit') ?>
            <input type="hidden" name="id">
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">NIM</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="nim" placeholder="nim">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Nama Mahasiswa</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="nama" placeholder="nama">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-2 col-form-label">Jenis Kelamin</label>
                <div class="col-md-10 form-inline">
                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="jk" value="Laki-Laki" checked>Laki-Laki
                        </label>
                    </div>
                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="jk" value="Perempuan" >Perempuan
                        </label>
                    </div>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Jurusan</label>
                <div class="col-sm-10">
                    <select class="form-control" name="jurusan">
                        <option value="Ilmu Komputer">Ilmu Komputer</option>
                        <option value="Matematika">Matematika</option>
                        <option value="Biologi">Biologi</option>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Foto</label>
                <div class="col-sm-10">
                    <input type="file" class="form-control" name="foto">
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-3">SIMPAN</button>
        </form>
    </div>
</section>