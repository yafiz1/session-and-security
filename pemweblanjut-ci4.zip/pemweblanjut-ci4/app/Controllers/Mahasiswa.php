<?php namespace App\Controllers;

use App\Models\MahasiswaModel;

class Mahasiswa extends BaseController
{
	public function index()
	{
		$model = new MahasiswaModel;

		//$model->getData();

		$data = [
			'title' 	=> 'Data Mahasiswa',
			'content' 	=> 'mahasiswa/v_grid',
			//'mhs'		=> $model->paginate(2),
			'mhs'		=> $model->paginate(2, 'bootstrap'),
			'pager' 	=> $model->pager
		];

		return view('template', $data);
	}

	public function add()
	{
		$data = [
			'title' 	=> 'Tambah Mahasiswa',
			'content' 	=> 'mahasiswa/v_form',
		];

		return view('template', $data);
	}

	public function mhs()
	{
		$model = new MahasiswaModel;
		$model->getData();

		$data = [
			'title' 	=> 'Data Mahasiswa',
			'content' 	=> 'mahasiswa/v_grid',
			'mhs'		=> $model->paginate(2, 'bootstrap'),
			'pager' 	=> $model->pager
		];

		return view('template', $data);
	}

	public function submit()
    {
		$id = $this->request->getPost('id');
		
        $data = array(
            'nim' => $this->request->getPost('nim'),
			'nama' => $this->request->getPost('nama'),
			'jenis_kelamin' => $this->request->getPost('jk'),
			'jurusan' => $this->request->getPost('jurusan'),
		);

		if($file = $this->request->getFile('foto'))
        {
            if ($file->isValid() && ! $file->hasMoved())
            {
				$newName = 'mhs_'.$file->getRandomName();
				$path = FCPATH.'uploads';
				$file->move($path, $newName);
				$data['foto'] = $newName;
			}
		}

		$model = new MahasiswaModel;
		
		if($id == "")
			$res = $model->insertData($data);
		else{
			$res = $model->updateData($data, $id);
		}
    }
}